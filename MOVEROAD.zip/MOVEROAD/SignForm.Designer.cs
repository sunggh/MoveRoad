﻿namespace MOVEROAD
{
    partial class SignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControlSign = new System.Windows.Forms.TabControl();
            this.tabPageNewInsert = new System.Windows.Forms.TabPage();
            this.textBoxdrafter = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxSubWork = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxMiddleWork = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonInsert = new System.Windows.Forms.Button();
            this.comboBoxDrafter = new System.Windows.Forms.ComboBox();
            this.comboBoxWork = new System.Windows.Forms.ComboBox();
            this.textBoxComment = new System.Windows.Forms.TextBox();
            this.textBoxContent = new System.Windows.Forms.TextBox();
            this.textBoxTitle = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageToMe = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxDetail_req = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxMemo = new System.Windows.Forms.TextBox();
            this.buttonTurn = new System.Windows.Forms.Button();
            this.buttonSign = new System.Windows.Forms.Button();
            this.dataGridViewRequest = new System.Windows.Forms.DataGridView();
            this.tabPageFromMe = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxDetail_turn = new System.Windows.Forms.TextBox();
            this.textBoxDetail_done = new System.Windows.Forms.TextBox();
            this.textBoxSignTurnMemo = new System.Windows.Forms.TextBox();
            this.dataGridViewSignTurnList = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridViewSignList = new System.Windows.Forms.DataGridView();
            this.tabControlSign.SuspendLayout();
            this.tabPageNewInsert.SuspendLayout();
            this.tabPageToMe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRequest)).BeginInit();
            this.tabPageFromMe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSignTurnList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSignList)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlSign
            // 
            this.tabControlSign.Controls.Add(this.tabPageNewInsert);
            this.tabControlSign.Controls.Add(this.tabPageToMe);
            this.tabControlSign.Controls.Add(this.tabPageFromMe);
            this.tabControlSign.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabControlSign.Location = new System.Drawing.Point(-3, 0);
            this.tabControlSign.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControlSign.Name = "tabControlSign";
            this.tabControlSign.SelectedIndex = 0;
            this.tabControlSign.Size = new System.Drawing.Size(858, 519);
            this.tabControlSign.TabIndex = 0;
            this.tabControlSign.SelectedIndexChanged += new System.EventHandler(this.tabControlSign_SelectedIndexChanged);
            // 
            // tabPageNewInsert
            // 
            this.tabPageNewInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.tabPageNewInsert.Controls.Add(this.textBoxdrafter);
            this.tabPageNewInsert.Controls.Add(this.label16);
            this.tabPageNewInsert.Controls.Add(this.comboBoxSubWork);
            this.tabPageNewInsert.Controls.Add(this.label15);
            this.tabPageNewInsert.Controls.Add(this.comboBoxMiddleWork);
            this.tabPageNewInsert.Controls.Add(this.label6);
            this.tabPageNewInsert.Controls.Add(this.buttonInsert);
            this.tabPageNewInsert.Controls.Add(this.comboBoxDrafter);
            this.tabPageNewInsert.Controls.Add(this.comboBoxWork);
            this.tabPageNewInsert.Controls.Add(this.textBoxComment);
            this.tabPageNewInsert.Controls.Add(this.textBoxContent);
            this.tabPageNewInsert.Controls.Add(this.textBoxTitle);
            this.tabPageNewInsert.Controls.Add(this.label5);
            this.tabPageNewInsert.Controls.Add(this.label4);
            this.tabPageNewInsert.Controls.Add(this.label3);
            this.tabPageNewInsert.Controls.Add(this.label2);
            this.tabPageNewInsert.Controls.Add(this.label1);
            this.tabPageNewInsert.Location = new System.Drawing.Point(4, 29);
            this.tabPageNewInsert.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageNewInsert.Name = "tabPageNewInsert";
            this.tabPageNewInsert.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageNewInsert.Size = new System.Drawing.Size(850, 486);
            this.tabPageNewInsert.TabIndex = 0;
            this.tabPageNewInsert.Text = "신규 결재 등록";
            // 
            // textBoxdrafter
            // 
            this.textBoxdrafter.Location = new System.Drawing.Point(303, 69);
            this.textBoxdrafter.Name = "textBoxdrafter";
            this.textBoxdrafter.ReadOnly = true;
            this.textBoxdrafter.Size = new System.Drawing.Size(100, 27);
            this.textBoxdrafter.TabIndex = 16;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(223, 67);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label16.Size = new System.Drawing.Size(74, 30);
            this.label16.TabIndex = 15;
            this.label16.Text = "기안자";
            // 
            // comboBoxSubWork
            // 
            this.comboBoxSubWork.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBoxSubWork.FormattingEnabled = true;
            this.comboBoxSubWork.Location = new System.Drawing.Point(662, 125);
            this.comboBoxSubWork.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxSubWork.Name = "comboBoxSubWork";
            this.comboBoxSubWork.Size = new System.Drawing.Size(121, 28);
            this.comboBoxSubWork.TabIndex = 14;
            this.comboBoxSubWork.SelectedIndexChanged += new System.EventHandler(this.comboBoxSubWork_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(597, 123);
            this.label15.Name = "label15";
            this.label15.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label15.Size = new System.Drawing.Size(59, 30);
            this.label15.TabIndex = 13;
            this.label15.Text = "업무";
            // 
            // comboBoxMiddleWork
            // 
            this.comboBoxMiddleWork.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBoxMiddleWork.FormattingEnabled = true;
            this.comboBoxMiddleWork.Location = new System.Drawing.Point(429, 125);
            this.comboBoxMiddleWork.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxMiddleWork.Name = "comboBoxMiddleWork";
            this.comboBoxMiddleWork.Size = new System.Drawing.Size(121, 28);
            this.comboBoxMiddleWork.TabIndex = 12;
            this.comboBoxMiddleWork.SelectedIndexChanged += new System.EventHandler(this.comboBoxMiddleWork_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(331, 122);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label6.Size = new System.Drawing.Size(93, 30);
            this.label6.TabIndex = 11;
            this.label6.Text = "업무 구분";
            // 
            // buttonInsert
            // 
            this.buttonInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.buttonInsert.FlatAppearance.BorderSize = 0;
            this.buttonInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonInsert.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonInsert.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonInsert.Location = new System.Drawing.Point(335, 422);
            this.buttonInsert.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonInsert.Name = "buttonInsert";
            this.buttonInsert.Size = new System.Drawing.Size(185, 55);
            this.buttonInsert.TabIndex = 10;
            this.buttonInsert.Text = "등록하기";
            this.buttonInsert.UseVisualStyleBackColor = false;
            this.buttonInsert.Click += new System.EventHandler(this.buttonInsert_Click);
            // 
            // comboBoxDrafter
            // 
            this.comboBoxDrafter.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBoxDrafter.FormattingEnabled = true;
            this.comboBoxDrafter.Location = new System.Drawing.Point(538, 69);
            this.comboBoxDrafter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxDrafter.Name = "comboBoxDrafter";
            this.comboBoxDrafter.Size = new System.Drawing.Size(121, 28);
            this.comboBoxDrafter.TabIndex = 9;
            // 
            // comboBoxWork
            // 
            this.comboBoxWork.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBoxWork.FormattingEnabled = true;
            this.comboBoxWork.Location = new System.Drawing.Point(160, 125);
            this.comboBoxWork.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxWork.Name = "comboBoxWork";
            this.comboBoxWork.Size = new System.Drawing.Size(121, 28);
            this.comboBoxWork.TabIndex = 8;
            this.comboBoxWork.SelectedIndexChanged += new System.EventHandler(this.comboBoxWork_SelectedIndexChanged);
            // 
            // textBoxComment
            // 
            this.textBoxComment.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxComment.Location = new System.Drawing.Point(125, 351);
            this.textBoxComment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxComment.Multiline = true;
            this.textBoxComment.Name = "textBoxComment";
            this.textBoxComment.Size = new System.Drawing.Size(658, 54);
            this.textBoxComment.TabIndex = 7;
            // 
            // textBoxContent
            // 
            this.textBoxContent.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxContent.Location = new System.Drawing.Point(125, 174);
            this.textBoxContent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxContent.Multiline = true;
            this.textBoxContent.Name = "textBoxContent";
            this.textBoxContent.Size = new System.Drawing.Size(658, 149);
            this.textBoxContent.TabIndex = 6;
            // 
            // textBoxTitle
            // 
            this.textBoxTitle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxTitle.Location = new System.Drawing.Point(125, 18);
            this.textBoxTitle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxTitle.Name = "textBoxTitle";
            this.textBoxTitle.Size = new System.Drawing.Size(658, 27);
            this.textBoxTitle.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(47, 351);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label5.Size = new System.Drawing.Size(74, 30);
            this.label5.TabIndex = 4;
            this.label5.Text = "코멘트";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(62, 174);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label4.Size = new System.Drawing.Size(59, 30);
            this.label4.TabIndex = 3;
            this.label4.Text = "내용";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(458, 67);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label3.Size = new System.Drawing.Size(74, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "결재자";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(62, 122);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label2.Size = new System.Drawing.Size(93, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "부서 선택";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(62, 16);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label1.Size = new System.Drawing.Size(59, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "제목";
            // 
            // tabPageToMe
            // 
            this.tabPageToMe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.tabPageToMe.Controls.Add(this.label11);
            this.tabPageToMe.Controls.Add(this.textBoxDetail_req);
            this.tabPageToMe.Controls.Add(this.label9);
            this.tabPageToMe.Controls.Add(this.label7);
            this.tabPageToMe.Controls.Add(this.textBoxMemo);
            this.tabPageToMe.Controls.Add(this.buttonTurn);
            this.tabPageToMe.Controls.Add(this.buttonSign);
            this.tabPageToMe.Controls.Add(this.dataGridViewRequest);
            this.tabPageToMe.Location = new System.Drawing.Point(4, 29);
            this.tabPageToMe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageToMe.Name = "tabPageToMe";
            this.tabPageToMe.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageToMe.Size = new System.Drawing.Size(850, 486);
            this.tabPageToMe.TabIndex = 1;
            this.tabPageToMe.Text = "결재 요청 내역";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(667, 16);
            this.label11.Name = "label11";
            this.label11.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label11.Size = new System.Drawing.Size(170, 30);
            this.label11.TabIndex = 7;
            this.label11.Text = "내용 상세보기";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxDetail_req
            // 
            this.textBoxDetail_req.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxDetail_req.Location = new System.Drawing.Point(667, 49);
            this.textBoxDetail_req.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxDetail_req.Multiline = true;
            this.textBoxDetail_req.Name = "textBoxDetail_req";
            this.textBoxDetail_req.ReadOnly = true;
            this.textBoxDetail_req.Size = new System.Drawing.Size(170, 266);
            this.textBoxDetail_req.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(11, 16);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label9.Size = new System.Drawing.Size(93, 30);
            this.label9.TabIndex = 5;
            this.label9.Text = "결재 내역";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(11, 354);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label7.Size = new System.Drawing.Size(59, 30);
            this.label7.TabIndex = 4;
            this.label7.Text = "메모";
            // 
            // textBoxMemo
            // 
            this.textBoxMemo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxMemo.Location = new System.Drawing.Point(86, 340);
            this.textBoxMemo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxMemo.Multiline = true;
            this.textBoxMemo.Name = "textBoxMemo";
            this.textBoxMemo.Size = new System.Drawing.Size(725, 62);
            this.textBoxMemo.TabIndex = 3;
            // 
            // buttonTurn
            // 
            this.buttonTurn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.buttonTurn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTurn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonTurn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonTurn.Location = new System.Drawing.Point(437, 424);
            this.buttonTurn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonTurn.Name = "buttonTurn";
            this.buttonTurn.Size = new System.Drawing.Size(214, 48);
            this.buttonTurn.TabIndex = 2;
            this.buttonTurn.Text = "반려하기";
            this.buttonTurn.UseVisualStyleBackColor = false;
            this.buttonTurn.Click += new System.EventHandler(this.buttonTurn_Click);
            // 
            // buttonSign
            // 
            this.buttonSign.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.buttonSign.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSign.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonSign.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSign.Location = new System.Drawing.Point(173, 424);
            this.buttonSign.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonSign.Name = "buttonSign";
            this.buttonSign.Size = new System.Drawing.Size(214, 48);
            this.buttonSign.TabIndex = 1;
            this.buttonSign.Text = "결재하기";
            this.buttonSign.UseVisualStyleBackColor = false;
            this.buttonSign.Click += new System.EventHandler(this.buttonSign_Click);
            // 
            // dataGridViewRequest
            // 
            this.dataGridViewRequest.AllowUserToAddRows = false;
            this.dataGridViewRequest.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewRequest.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dataGridViewRequest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewRequest.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridViewRequest.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRequest.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewRequest.ColumnHeadersHeight = 29;
            this.dataGridViewRequest.EnableHeadersVisualStyles = false;
            this.dataGridViewRequest.GridColor = System.Drawing.Color.Black;
            this.dataGridViewRequest.Location = new System.Drawing.Point(11, 49);
            this.dataGridViewRequest.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewRequest.Name = "dataGridViewRequest";
            this.dataGridViewRequest.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRequest.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewRequest.RowHeadersVisible = false;
            this.dataGridViewRequest.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewRequest.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewRequest.RowTemplate.Height = 27;
            this.dataGridViewRequest.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewRequest.Size = new System.Drawing.Size(639, 268);
            this.dataGridViewRequest.TabIndex = 0;
            this.dataGridViewRequest.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRequest_CellDoubleClick);
            // 
            // tabPageFromMe
            // 
            this.tabPageFromMe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.tabPageFromMe.Controls.Add(this.label14);
            this.tabPageFromMe.Controls.Add(this.label13);
            this.tabPageFromMe.Controls.Add(this.label12);
            this.tabPageFromMe.Controls.Add(this.textBoxDetail_turn);
            this.tabPageFromMe.Controls.Add(this.textBoxDetail_done);
            this.tabPageFromMe.Controls.Add(this.textBoxSignTurnMemo);
            this.tabPageFromMe.Controls.Add(this.dataGridViewSignTurnList);
            this.tabPageFromMe.Controls.Add(this.label10);
            this.tabPageFromMe.Controls.Add(this.label8);
            this.tabPageFromMe.Controls.Add(this.dataGridViewSignList);
            this.tabPageFromMe.Location = new System.Drawing.Point(4, 29);
            this.tabPageFromMe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageFromMe.Name = "tabPageFromMe";
            this.tabPageFromMe.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageFromMe.Size = new System.Drawing.Size(850, 486);
            this.tabPageFromMe.TabIndex = 2;
            this.tabPageFromMe.Text = "내가 등록한 결재";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(16, 425);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label14.Size = new System.Drawing.Size(59, 30);
            this.label14.TabIndex = 10;
            this.label14.Text = "메모";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(645, 221);
            this.label13.Name = "label13";
            this.label13.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label13.Size = new System.Drawing.Size(182, 30);
            this.label13.TabIndex = 9;
            this.label13.Text = "내용 상세보기";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(645, 2);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label12.Size = new System.Drawing.Size(182, 30);
            this.label12.TabIndex = 8;
            this.label12.Text = "내용 상세보기";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxDetail_turn
            // 
            this.textBoxDetail_turn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxDetail_turn.Location = new System.Drawing.Point(645, 254);
            this.textBoxDetail_turn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxDetail_turn.Multiline = true;
            this.textBoxDetail_turn.Name = "textBoxDetail_turn";
            this.textBoxDetail_turn.ReadOnly = true;
            this.textBoxDetail_turn.Size = new System.Drawing.Size(182, 143);
            this.textBoxDetail_turn.TabIndex = 7;
            // 
            // textBoxDetail_done
            // 
            this.textBoxDetail_done.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxDetail_done.Location = new System.Drawing.Point(645, 38);
            this.textBoxDetail_done.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxDetail_done.Multiline = true;
            this.textBoxDetail_done.Name = "textBoxDetail_done";
            this.textBoxDetail_done.ReadOnly = true;
            this.textBoxDetail_done.Size = new System.Drawing.Size(182, 176);
            this.textBoxDetail_done.TabIndex = 6;
            // 
            // textBoxSignTurnMemo
            // 
            this.textBoxSignTurnMemo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxSignTurnMemo.Location = new System.Drawing.Point(85, 412);
            this.textBoxSignTurnMemo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxSignTurnMemo.Multiline = true;
            this.textBoxSignTurnMemo.Name = "textBoxSignTurnMemo";
            this.textBoxSignTurnMemo.ReadOnly = true;
            this.textBoxSignTurnMemo.Size = new System.Drawing.Size(742, 55);
            this.textBoxSignTurnMemo.TabIndex = 5;
            // 
            // dataGridViewSignTurnList
            // 
            this.dataGridViewSignTurnList.AllowUserToAddRows = false;
            this.dataGridViewSignTurnList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSignTurnList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dataGridViewSignTurnList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewSignTurnList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridViewSignTurnList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSignTurnList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewSignTurnList.ColumnHeadersHeight = 29;
            this.dataGridViewSignTurnList.EnableHeadersVisualStyles = false;
            this.dataGridViewSignTurnList.GridColor = System.Drawing.Color.Black;
            this.dataGridViewSignTurnList.Location = new System.Drawing.Point(21, 248);
            this.dataGridViewSignTurnList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewSignTurnList.Name = "dataGridViewSignTurnList";
            this.dataGridViewSignTurnList.ReadOnly = true;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSignTurnList.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewSignTurnList.RowHeadersVisible = false;
            this.dataGridViewSignTurnList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dataGridViewSignTurnList.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewSignTurnList.RowTemplate.Height = 27;
            this.dataGridViewSignTurnList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSignTurnList.Size = new System.Drawing.Size(617, 160);
            this.dataGridViewSignTurnList.TabIndex = 0;
            this.dataGridViewSignTurnList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSignTurnList_CellDoubleClick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(21, 209);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label10.Size = new System.Drawing.Size(93, 30);
            this.label10.TabIndex = 3;
            this.label10.Text = "반려 내역";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(21, 4);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label8.Size = new System.Drawing.Size(93, 30);
            this.label8.TabIndex = 2;
            this.label8.Text = "결재 내역";
            // 
            // dataGridViewSignList
            // 
            this.dataGridViewSignList.AllowUserToAddRows = false;
            this.dataGridViewSignList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSignList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dataGridViewSignList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewSignList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridViewSignList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSignList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewSignList.ColumnHeadersHeight = 29;
            this.dataGridViewSignList.EnableHeadersVisualStyles = false;
            this.dataGridViewSignList.GridColor = System.Drawing.Color.Black;
            this.dataGridViewSignList.Location = new System.Drawing.Point(21, 38);
            this.dataGridViewSignList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewSignList.Name = "dataGridViewSignList";
            this.dataGridViewSignList.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSignList.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewSignList.RowHeadersVisible = false;
            this.dataGridViewSignList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dataGridViewSignList.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewSignList.RowTemplate.Height = 27;
            this.dataGridViewSignList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSignList.Size = new System.Drawing.Size(617, 160);
            this.dataGridViewSignList.TabIndex = 0;
            this.dataGridViewSignList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSignList_CellDoubleClick);
            // 
            // SignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.ClientSize = new System.Drawing.Size(851, 515);
            this.Controls.Add(this.tabControlSign);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "SignForm";
            this.Text = "SignForm";
            this.tabControlSign.ResumeLayout(false);
            this.tabPageNewInsert.ResumeLayout(false);
            this.tabPageNewInsert.PerformLayout();
            this.tabPageToMe.ResumeLayout(false);
            this.tabPageToMe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRequest)).EndInit();
            this.tabPageFromMe.ResumeLayout(false);
            this.tabPageFromMe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSignTurnList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSignList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlSign;
        private System.Windows.Forms.TabPage tabPageNewInsert;
        private System.Windows.Forms.Button buttonInsert;
        private System.Windows.Forms.ComboBox comboBoxDrafter;
        private System.Windows.Forms.ComboBox comboBoxWork;
        private System.Windows.Forms.TextBox textBoxComment;
        private System.Windows.Forms.TextBox textBoxContent;
        private System.Windows.Forms.TextBox textBoxTitle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPageToMe;
        private System.Windows.Forms.TabPage tabPageFromMe;
        private System.Windows.Forms.TextBox textBoxMemo;
        private System.Windows.Forms.Button buttonTurn;
        private System.Windows.Forms.Button buttonSign;
        private System.Windows.Forms.DataGridView dataGridViewSignList;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxSignTurnMemo;
        private System.Windows.Forms.DataGridView dataGridViewSignTurnList;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxDetail_req;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxDetail_turn;
        private System.Windows.Forms.TextBox textBoxDetail_done;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dataGridViewRequest;
        private System.Windows.Forms.ComboBox comboBoxSubWork;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxMiddleWork;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxdrafter;
        private System.Windows.Forms.Label label16;
    }
}