﻿namespace MOVEROAD
{
    partial class EditUsers_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxExistingAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxExistingPhone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxExistingGender = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxExistingAge = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxExistingName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxExistingGrade = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxExistingDepart = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxExistingIndex = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxEditGender = new System.Windows.Forms.ComboBox();
            this.comboBoxEditGrade = new System.Windows.Forms.ComboBox();
            this.comboBoxEditDepart = new System.Windows.Forms.ComboBox();
            this.textBoxEditAddress = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxEditPhone = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxEditAge = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxEditName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxEditIndex = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxExistingAddress);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBoxExistingPhone);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBoxExistingGender);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBoxExistingAge);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBoxExistingName);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxExistingGrade);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxExistingDepart);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxExistingIndex);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(621, 120);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "기존 정보";
            // 
            // textBoxExistingAddress
            // 
            this.textBoxExistingAddress.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingAddress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingAddress.Location = new System.Drawing.Point(194, 83);
            this.textBoxExistingAddress.Name = "textBoxExistingAddress";
            this.textBoxExistingAddress.ReadOnly = true;
            this.textBoxExistingAddress.Size = new System.Drawing.Size(336, 23);
            this.textBoxExistingAddress.TabIndex = 15;
            this.textBoxExistingAddress.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(159, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 15);
            this.label8.TabIndex = 14;
            this.label8.Text = "주소";
            // 
            // textBoxExistingPhone
            // 
            this.textBoxExistingPhone.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingPhone.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingPhone.Location = new System.Drawing.Point(37, 83);
            this.textBoxExistingPhone.Name = "textBoxExistingPhone";
            this.textBoxExistingPhone.ReadOnly = true;
            this.textBoxExistingPhone.Size = new System.Drawing.Size(116, 23);
            this.textBoxExistingPhone.TabIndex = 13;
            this.textBoxExistingPhone.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "H.P";
            // 
            // textBoxExistingGender
            // 
            this.textBoxExistingGender.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingGender.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingGender.Location = new System.Drawing.Point(331, 56);
            this.textBoxExistingGender.Name = "textBoxExistingGender";
            this.textBoxExistingGender.ReadOnly = true;
            this.textBoxExistingGender.Size = new System.Drawing.Size(88, 23);
            this.textBoxExistingGender.TabIndex = 11;
            this.textBoxExistingGender.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(296, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "성별";
            // 
            // textBoxExistingAge
            // 
            this.textBoxExistingAge.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingAge.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingAge.Location = new System.Drawing.Point(190, 56);
            this.textBoxExistingAge.Name = "textBoxExistingAge";
            this.textBoxExistingAge.ReadOnly = true;
            this.textBoxExistingAge.Size = new System.Drawing.Size(88, 23);
            this.textBoxExistingAge.TabIndex = 9;
            this.textBoxExistingAge.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(155, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "나이";
            // 
            // textBoxExistingName
            // 
            this.textBoxExistingName.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingName.Location = new System.Drawing.Point(37, 56);
            this.textBoxExistingName.Name = "textBoxExistingName";
            this.textBoxExistingName.ReadOnly = true;
            this.textBoxExistingName.Size = new System.Drawing.Size(88, 23);
            this.textBoxExistingName.TabIndex = 7;
            this.textBoxExistingName.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "이름";
            // 
            // textBoxExistingGrade
            // 
            this.textBoxExistingGrade.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingGrade.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingGrade.Location = new System.Drawing.Point(331, 29);
            this.textBoxExistingGrade.Name = "textBoxExistingGrade";
            this.textBoxExistingGrade.ReadOnly = true;
            this.textBoxExistingGrade.Size = new System.Drawing.Size(88, 23);
            this.textBoxExistingGrade.TabIndex = 5;
            this.textBoxExistingGrade.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(296, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "직위";
            // 
            // textBoxExistingDepart
            // 
            this.textBoxExistingDepart.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingDepart.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingDepart.Location = new System.Drawing.Point(190, 29);
            this.textBoxExistingDepart.Name = "textBoxExistingDepart";
            this.textBoxExistingDepart.ReadOnly = true;
            this.textBoxExistingDepart.Size = new System.Drawing.Size(88, 23);
            this.textBoxExistingDepart.TabIndex = 3;
            this.textBoxExistingDepart.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(143, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "부서명";
            // 
            // textBoxExistingIndex
            // 
            this.textBoxExistingIndex.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxExistingIndex.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxExistingIndex.Location = new System.Drawing.Point(37, 29);
            this.textBoxExistingIndex.Name = "textBoxExistingIndex";
            this.textBoxExistingIndex.ReadOnly = true;
            this.textBoxExistingIndex.Size = new System.Drawing.Size(88, 23);
            this.textBoxExistingIndex.TabIndex = 1;
            this.textBoxExistingIndex.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "No.";
            // 
            // buttonSave
            // 
            this.buttonSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.buttonSave.FlatAppearance.BorderSize = 0;
            this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSave.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonSave.ForeColor = System.Drawing.Color.White;
            this.buttonSave.Location = new System.Drawing.Point(545, 177);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(81, 23);
            this.buttonSave.TabIndex = 17;
            this.buttonSave.Text = "수정";
            this.buttonSave.UseVisualStyleBackColor = false;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonClose.ForeColor = System.Drawing.Color.White;
            this.buttonClose.Location = new System.Drawing.Point(545, 235);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(81, 23);
            this.buttonClose.TabIndex = 18;
            this.buttonClose.Text = "닫기";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxEditGender);
            this.groupBox2.Controls.Add(this.comboBoxEditGrade);
            this.groupBox2.Controls.Add(this.comboBoxEditDepart);
            this.groupBox2.Controls.Add(this.textBoxEditAddress);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBoxEditPhone);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.textBoxEditAge);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.textBoxEditName);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.textBoxEditIndex);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.groupBox2.Location = new System.Drawing.Point(12, 138);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(527, 120);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "정보 수정 (빈칸을 모두 채워주십시오)";
            // 
            // comboBoxEditGender
            // 
            this.comboBoxEditGender.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBoxEditGender.FormattingEnabled = true;
            this.comboBoxEditGender.Items.AddRange(new object[] {
            "남자",
            "여자"});
            this.comboBoxEditGender.Location = new System.Drawing.Point(331, 56);
            this.comboBoxEditGender.Name = "comboBoxEditGender";
            this.comboBoxEditGender.Size = new System.Drawing.Size(88, 23);
            this.comboBoxEditGender.TabIndex = 18;
            // 
            // comboBoxEditGrade
            // 
            this.comboBoxEditGrade.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBoxEditGrade.FormattingEnabled = true;
            this.comboBoxEditGrade.Items.AddRange(new object[] {
            "사장",
            "부서장",
            "사원"});
            this.comboBoxEditGrade.Location = new System.Drawing.Point(331, 29);
            this.comboBoxEditGrade.Name = "comboBoxEditGrade";
            this.comboBoxEditGrade.Size = new System.Drawing.Size(88, 23);
            this.comboBoxEditGrade.TabIndex = 17;
            this.comboBoxEditGrade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBoxEditGrade_KeyPress);
            // 
            // comboBoxEditDepart
            // 
            this.comboBoxEditDepart.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBoxEditDepart.FormattingEnabled = true;
            this.comboBoxEditDepart.Location = new System.Drawing.Point(190, 29);
            this.comboBoxEditDepart.Name = "comboBoxEditDepart";
            this.comboBoxEditDepart.Size = new System.Drawing.Size(88, 23);
            this.comboBoxEditDepart.TabIndex = 16;
            this.comboBoxEditDepart.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBoxEditDepart_KeyPress);
            // 
            // textBoxEditAddress
            // 
            this.textBoxEditAddress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxEditAddress.Location = new System.Drawing.Point(194, 83);
            this.textBoxEditAddress.Name = "textBoxEditAddress";
            this.textBoxEditAddress.Size = new System.Drawing.Size(315, 23);
            this.textBoxEditAddress.TabIndex = 15;
            this.textBoxEditAddress.DoubleClick += new System.EventHandler(this.textBoxEditAddress_DoubleClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(159, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 15);
            this.label9.TabIndex = 14;
            this.label9.Text = "주소";
            // 
            // textBoxEditPhone
            // 
            this.textBoxEditPhone.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxEditPhone.Location = new System.Drawing.Point(37, 83);
            this.textBoxEditPhone.Name = "textBoxEditPhone";
            this.textBoxEditPhone.Size = new System.Drawing.Size(116, 23);
            this.textBoxEditPhone.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 15);
            this.label10.TabIndex = 12;
            this.label10.Text = "H.P";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(296, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 15);
            this.label11.TabIndex = 10;
            this.label11.Text = "성별";
            // 
            // textBoxEditAge
            // 
            this.textBoxEditAge.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxEditAge.Location = new System.Drawing.Point(190, 56);
            this.textBoxEditAge.Name = "textBoxEditAge";
            this.textBoxEditAge.Size = new System.Drawing.Size(88, 23);
            this.textBoxEditAge.TabIndex = 9;
            this.textBoxEditAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxEditAge_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(155, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 15);
            this.label12.TabIndex = 8;
            this.label12.Text = "나이";
            // 
            // textBoxEditName
            // 
            this.textBoxEditName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxEditName.Location = new System.Drawing.Point(37, 56);
            this.textBoxEditName.Name = "textBoxEditName";
            this.textBoxEditName.Size = new System.Drawing.Size(88, 23);
            this.textBoxEditName.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(2, 59);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 15);
            this.label13.TabIndex = 6;
            this.label13.Text = "이름";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(296, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 15);
            this.label14.TabIndex = 4;
            this.label14.Text = "직위";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(143, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 15);
            this.label15.TabIndex = 2;
            this.label15.Text = "부서명";
            // 
            // textBoxEditIndex
            // 
            this.textBoxEditIndex.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxEditIndex.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxEditIndex.Location = new System.Drawing.Point(37, 29);
            this.textBoxEditIndex.Name = "textBoxEditIndex";
            this.textBoxEditIndex.ReadOnly = true;
            this.textBoxEditIndex.Size = new System.Drawing.Size(88, 23);
            this.textBoxEditIndex.TabIndex = 1;
            this.textBoxEditIndex.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 15);
            this.label16.TabIndex = 0;
            this.label16.Text = "No.";
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(71)))), ((int)(((byte)(117)))));
            this.buttonDelete.FlatAppearance.BorderSize = 0;
            this.buttonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDelete.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buttonDelete.ForeColor = System.Drawing.Color.White;
            this.buttonDelete.Location = new System.Drawing.Point(545, 206);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(81, 23);
            this.buttonDelete.TabIndex = 19;
            this.buttonDelete.Text = "삭제";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // EditUsers_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(645, 270);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditUsers_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditUsers_form";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxExistingIndex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxExistingAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxExistingPhone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxExistingGender;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxExistingAge;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxExistingName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxExistingGrade;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxExistingDepart;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxEditGender;
        private System.Windows.Forms.ComboBox comboBoxEditGrade;
        private System.Windows.Forms.ComboBox comboBoxEditDepart;
        private System.Windows.Forms.TextBox textBoxEditAddress;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxEditPhone;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxEditAge;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxEditName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxEditIndex;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button buttonDelete;
    }
}